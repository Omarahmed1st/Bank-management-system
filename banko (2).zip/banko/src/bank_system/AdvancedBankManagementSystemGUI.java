package bank_system;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class BankAccount {
    private String accountNumber;
    private double balance;
    private ArrayList<String> transactionHistory;

    public BankAccount(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.transactionHistory = new ArrayList<>();
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public ArrayList<String> getTransactionHistory() {
        return transactionHistory;
    }

    public void deposit(double amount) {
        balance += amount;
        transactionHistory.add("Deposit: +" + formatAmount(amount));
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            transactionHistory.add("Withdrawal: -" + formatAmount(amount));
        } else {
            transactionHistory.add("Failed Withdrawal: Insufficient Balance");
        }
    }

    public void transfer(BankAccount targetAccount, double amount) {
        if (balance >= amount) {
            this.withdraw(amount);
            targetAccount.deposit(amount);
            transactionHistory.add("Transfer to " + targetAccount.getAccountNumber() + ": -" + formatAmount(amount));
            targetAccount.getTransactionHistory().add("Transfer from " + this.getAccountNumber() + ": +" + formatAmount(amount));
        } else {
            transactionHistory.add("Failed Transfer to " + targetAccount.getAccountNumber() + ": Insufficient Balance");
        }
    }

    private String formatAmount(double amount) {
        DecimalFormat df = new DecimalFormat("#.##");
        return df.format(amount);
    }
}

enum AccountType {
    SAVINGS,
    CHECKING
}

class DuplicateAccountException extends Exception {
    public DuplicateAccountException(String message) {
        super(message);
    }
}
class EmptyFieldException extends Exception {
    public EmptyFieldException(String message) {
        super(message);
    }
}
class NegativeBalanceException extends Exception {
    public NegativeBalanceException(String message) {
        super(message);
    }
}

public class AdvancedBankManagementSystemGUI extends JFrame {
    private Map<String, BankAccount> accountsMap;

    public AdvancedBankManagementSystemGUI() {
        setTitle("Bank Management System");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        accountsMap = new HashMap<>();

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Actions", TitledBorder.CENTER, TitledBorder.TOP));

        JButton addButton = createStyledButton("Add Account", new Color(60, 179, 113));
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String accountNumber = JOptionPane.showInputDialog("Enter Account Number:");
                    if (accountNumber == null || accountNumber.trim().isEmpty()) {
                        throw new EmptyFieldException("Account number cannot be empty.");
                    }if (accountsMap.containsKey(accountNumber)) {
                        throw new DuplicateAccountException("Account number already exists.");
                    }
                    double initialBalance = Double.parseDouble(JOptionPane.showInputDialog("Enter Initial Balance:"));
                    if (initialBalance < 0) {
                        throw new NegativeBalanceException("Initial balance cannot be negative.");
                    }
                    AccountType accountType = (AccountType) JOptionPane.showInputDialog(null,"Choose Account Type:", "Account Type", JOptionPane.QUESTION_MESSAGE, null, AccountType.values(), AccountType.SAVINGS);

                    BankAccount account = new BankAccount(accountNumber, initialBalance);
                    accountsMap.put(accountNumber, account);
                    JOptionPane.showMessageDialog(null, "Account Added Successfully!");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (EmptyFieldException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }catch (DuplicateAccountException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }catch (NegativeBalanceException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }catch (NullPointerException ex) {
                    JOptionPane.showMessageDialog(null, "Operation cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        JButton removeButton = createStyledButton("Remove Account", new Color(255, 69, 0));
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String accountNumber = JOptionPane.showInputDialog("Enter Account Number:");
                if (accountNumber != null && accountsMap.containsKey(accountNumber)) {
                    accountsMap.remove(accountNumber);
                    JOptionPane.showMessageDialog(null, "Account Removed Successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Account not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton displayButton = createStyledButton("Display Accounts", new Color(30, 144, 255));
        displayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder accountsInfo = new StringBuilder();
                for (Map.Entry<String, BankAccount> entry : accountsMap.entrySet()) {
                    BankAccount account = entry.getValue();
                    accountsInfo.append("Account Number: ").append(account.getAccountNumber())
                            .append(", Balance: ").append(account.getBalance()).append("\n");
                    ArrayList<String> transactions = account.getTransactionHistory();
                    if (!transactions.isEmpty()) {
                        accountsInfo.append("Transaction History:\n");
                        for (String transaction : transactions) {
                            accountsInfo.append("- ").append(transaction).append("\n");
                        }
                    }
                    accountsInfo.append("\n");
                }
                JOptionPane.showMessageDialog(null, accountsInfo.toString());
            }
        });

        JButton transactionButton = createStyledButton("Make Transaction", new Color(72, 209, 204));
        transactionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String accountNumber = JOptionPane.showInputDialog("Enter Account Number:");
                    if (accountNumber != null && accountsMap.containsKey(accountNumber)) {
                        BankAccount account = accountsMap.get(accountNumber);
                        String[] options = {"Deposit", "Withdraw"};
                        int choice = JOptionPane.showOptionDialog(null,
                                "Choose Transaction Type:", "Transaction",
                                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                                null, options, options[0]);
                        double amount = Double.parseDouble(JOptionPane.showInputDialog("Enter Amount:"));
                        if (choice == 0) {
                            account.deposit(amount);
                            JOptionPane.showMessageDialog(null, "Deposit Successful!");
                        } else if (choice == 1) {
                            account.withdraw(amount);
                            JOptionPane.showMessageDialog(null, "Withdrawal Successful!");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Account not found!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (NullPointerException ex) {
                    JOptionPane.showMessageDialog(null, "Operation cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        JButton transferButton = createStyledButton("Transfer Money", new Color(218, 165, 32));
        transferButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String fromAccountNumber = JOptionPane.showInputDialog("Enter Your Account Number:");
                    if (fromAccountNumber == null || !accountsMap.containsKey(fromAccountNumber)) {
                        throw new EmptyFieldException("Source account not found or empty.");
                    }

                    String toAccountNumber = JOptionPane.showInputDialog("Enter Recipient Account Number:");
                    if (toAccountNumber == null || !accountsMap.containsKey(toAccountNumber)) {
                        throw new EmptyFieldException("Destination account not found or empty.");
                    }

                    double amount = Double.parseDouble(JOptionPane.showInputDialog("Enter Amount to Transfer:"));
                    BankAccount fromAccount = accountsMap.get(fromAccountNumber);
                    BankAccount toAccount = accountsMap.get(toAccountNumber);

                    fromAccount.transfer(toAccount, amount);
                    JOptionPane.showMessageDialog(null, "Transfer Successful!");

                }                     catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (EmptyFieldException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } catch (NullPointerException ex) {
                    JOptionPane.showMessageDialog(null, "Operation cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
                }
            }

    });

        buttonPanel.add(addButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(removeButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(displayButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(transactionButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(transferButton);

        mainPanel.add(buttonPanel, BorderLayout.CENTER);

    add(mainPanel);
    setVisible(true);
}

private JButton createStyledButton(String text, Color color) {
    JButton button = new JButton(text);
    button.setBackground(color);
    button.setForeground(Color.WHITE);
    button.setFocusPainted(false);
    button.setFont(new Font("Tahoma", Font.BOLD, 14));
    button.setAlignmentX(Component.CENTER_ALIGNMENT);
    button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
    return button;
}

public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> new AdvancedBankManagementSystemGUI());
}
}
